"""Command line for the preregistered Jev audit (plan/v1 Task 06).

    uv run --frozen python bench/jev_audit/run.py --write-preregistration [--source DIR]
    uv run --frozen python bench/jev_audit/run.py --check-preregistration [--source DIR]
    uv run --frozen python bench/jev_audit/run.py --execute --out DIR [--source DIR]
    uv run --frozen python bench/jev_audit/run.py --finalize DIR
    uv run --frozen python bench/jev_audit/run.py --check-receipts DIR

Every command writes one JSON object to stdout and exits 0 on success or 1
on a reported failure. ``--execute`` requires the already exported
``JEV_API_KEY``; it is read only inside the adapter constructor and is never
printed, journaled or echoed in any error. A passing ``--check-preregistration``
is a consistency statement, not permission to collect.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

_BENCH_DIR = Path(__file__).resolve().parents[1]
if str(_BENCH_DIR) not in sys.path:
    sys.path.insert(0, str(_BENCH_DIR))

from actseal.errors import ActsealError  # noqa: E402 - after the import path is prepared
from jev_audit import protocol  # noqa: E402
from jev_audit.collect import execute  # noqa: E402
from jev_audit.journal import JournalError  # noqa: E402
from jev_audit.receipts import check_run, finalize  # noqa: E402
from jev_audit.source import (  # noqa: E402
    DEFAULT_SOURCE_DIR,
    SourceError,
    selection_from_files,
    verify_source,
)

_FAILURES = (ActsealError, SourceError, JournalError, OSError, NotImplementedError)


def _emit(document: dict[str, object]) -> None:
    sys.stdout.write(json.dumps(document, sort_keys=True, ensure_ascii=False, allow_nan=False))
    sys.stdout.write("\n")
    sys.stdout.flush()


def _write_preregistration(data_dir: Path, source_dir: Path) -> dict[str, object]:
    files = verify_source(source_dir)
    selection = selection_from_files(files)
    data = protocol.build_data_files(selection, files)
    protocol.write_data_files(data_dir, data)
    verified = protocol.verify_preregistration(data_dir, source_dir=source_dir)
    return {
        "command": "write-preregistration",
        "data_dir": str(data_dir),
        "files": sorted(data),
        "preregistration_sha256": verified.preregistration_sha256,
        "lock_sha256": verified.lock.sha256,
        "findings": list(verified.findings),
        "statement": protocol.REVIEW_GATE,
    }


def _check_preregistration(data_dir: Path, source_dir: Path) -> tuple[dict[str, object], bool]:
    source: Path | None = source_dir if source_dir.is_dir() else None
    verified = protocol.verify_preregistration(data_dir, source_dir=source)
    findings = list(verified.findings)
    if source is None:
        findings.append("source: cached source directory is unavailable")
    passed = not findings and verified.source_verified
    producer = verified.preregistration["producer"]
    python_version = producer.get("python_version") if isinstance(producer, dict) else None
    return (
        {
            "command": "check-preregistration",
            "data_dir": str(data_dir),
            "source_dir": str(source_dir),
            "source_verified": verified.source_verified,
            "findings": findings,
            "passed": passed,
            "preregistration_sha256": verified.preregistration_sha256,
            "lock_sha256": verified.lock.sha256,
            "scheduled": len(verified.entries),
            "python_version": python_version,
            "statement": protocol.REVIEW_GATE,
        },
        passed,
    )


def _summary(report: dict[str, object], command: str) -> dict[str, object]:
    return {"command": command, **report}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="jev_audit", allow_abbrev=False, description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--write-preregistration", action="store_true")
    action.add_argument("--check-preregistration", action="store_true")
    action.add_argument("--execute", action="store_true")
    action.add_argument("--finalize", metavar="RUN_DIR", type=Path)
    action.add_argument("--check-receipts", metavar="RUN_DIR", type=Path)
    parser.add_argument("--data", type=Path, default=protocol.DATA_DIR)
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE_DIR)
    parser.add_argument("--out", type=Path, help="new run directory for --execute")
    args = parser.parse_args(argv)
    try:
        if args.write_preregistration:
            _emit(_write_preregistration(args.data, args.source))
            return 0
        if args.check_preregistration:
            report, passed = _check_preregistration(args.data, args.source)
            _emit(report)
            return 0 if passed else 1
        if args.execute:
            if args.out is None:
                parser.error("--execute requires --out RUN_DIR")
            receipt = execute(args.out, data_dir=args.data, source_dir=args.source)
            report = check_run(args.out)
            _emit(_summary({**report, "receipt": str(receipt)}, "execute"))
            return 0 if report["consistent"] else 1
        if args.finalize is not None:
            receipt = finalize(args.finalize)
            report = check_run(args.finalize)
            _emit(_summary({**report, "receipt": str(receipt)}, "finalize"))
            return 0 if report["consistent"] else 1
        report = check_run(args.check_receipts)
        _emit(_summary(report, "check-receipts"))
        return 0 if report["consistent"] else 1
    except _FAILURES as exc:
        _emit({"error": f"{type(exc).__name__}: {exc}"})
        return 1


if __name__ == "__main__":
    sys.exit(main())
