"""Prespecified descriptive metrics, computed per cohort and never pooled.

Valid answers are every normalized :class:`ChoiceAnswer`, including answers
that ABSTAIN (below threshold) or DENY (disallowed choice). Failure captures
have no probability vector and contribute nothing to reliability, ECE or
Brier; they are counted by failure code. Unattempted and
started-without-capture cases are neither answers nor abstentions.

Reliability bins use the normalized probability of the provider's SELECTED
option (never vendor confidence, never an argmax) and whether that selected
option equals the gold label. Ten equal-width bins with edges ``i / 10``:
bin ``i`` holds ``edges[i] <= p < edges[i + 1]`` for ``i`` in 0..8 and bin 9
holds ``0.9 <= p <= 1.0``; membership is decided by Python float comparison
against those edges, never by ``int(p * 10)`` (``0.7 * 10`` is not ``7.0``).

ECE is ``sum over nonempty bins of n_bin / n_valid * |mean selected
probability - selected-choice accuracy|``. The multiclass Brier score is the
mean over valid answers of ``sum over all options of (normalized probability
- one_hot_gold) ** 2`` with no division by the option count, so its range is
[0, 2]. Empty bins, metrics with ``n_valid = 0`` and unmeasured spend are
``None`` (JSON ``null``); nothing here can produce NaN or Infinity.
"""

from __future__ import annotations

import math
from collections import Counter
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Final

from actseal.errors import SchemaError
from actseal.records import CapturedOutcome, Case, ChoiceAnswer, Outcome, PolicyDecision
from actseal.serialization import strict_json_loads

__all__ = [
    "BIN_COUNT",
    "BIN_EDGES",
    "CohortRecord",
    "ValidAnswer",
    "bin_index",
    "brier",
    "cohort_summary",
    "ece",
    "reliability_bins",
    "usage_from_body",
    "valid_answers",
]

BIN_COUNT: Final = 10
BIN_EDGES: Final[tuple[float, ...]] = tuple(i / 10 for i in range(BIN_COUNT + 1))
_ACTIONS: Final = ("ACT", "ABSTAIN", "ESCALATE", "DENY")


@dataclass(frozen=True, slots=True)
class CohortRecord:
    """One captured case with its recomputed outcome and decision."""

    case: Case
    capture: CapturedOutcome
    outcome: Outcome
    decision: PolicyDecision


@dataclass(frozen=True, slots=True)
class ValidAnswer:
    selected_probability: float
    correct: bool
    probabilities: tuple[tuple[str, float], ...]
    gold: str


def bin_index(probability: float) -> int:
    """The bin holding ``probability``; exact float comparison against the edges."""
    if not 0.0 <= probability <= 1.0:  # also rejects NaN
        raise SchemaError("probability: must be a float in [0, 1]")
    index = 0
    for candidate in range(1, BIN_COUNT):
        if probability >= BIN_EDGES[candidate]:
            index = candidate
    return index


def valid_answers(records: Sequence[CohortRecord]) -> tuple[ValidAnswer, ...]:
    return tuple(
        ValidAnswer(
            record.outcome.selected_probability,
            record.outcome.choice == record.case.expected_label,
            record.outcome.probabilities,
            record.case.expected_label,
        )
        for record in records
        if isinstance(record.outcome, ChoiceAnswer)
    )


def reliability_bins(valid: Sequence[ValidAnswer]) -> list[dict[str, object]]:
    buckets: list[list[ValidAnswer]] = [[] for _ in range(BIN_COUNT)]
    for answer in valid:
        buckets[bin_index(answer.selected_probability)].append(answer)
    rows: list[dict[str, object]] = []
    for index, bucket in enumerate(buckets):
        count = len(bucket)
        rows.append(
            {
                "bin": index,
                "lower": BIN_EDGES[index],
                "upper": BIN_EDGES[index + 1],
                "upper_inclusive": index == BIN_COUNT - 1,
                "count": count,
                "mean_selected_probability": (
                    math.fsum(a.selected_probability for a in bucket) / count if count else None
                ),
                "accuracy": sum(a.correct for a in bucket) / count if count else None,
            }
        )
    return rows


def ece(valid: Sequence[ValidAnswer]) -> float | None:
    if not valid:
        return None
    terms: list[float] = []
    for row in reliability_bins(valid):
        count = row["count"]
        mean = row["mean_selected_probability"]
        accuracy = row["accuracy"]
        if (
            isinstance(count, int)
            and count
            and isinstance(mean, float)
            and isinstance(accuracy, float)
        ):
            terms.append(count / len(valid) * abs(mean - accuracy))
    return math.fsum(terms)


def brier(valid: Sequence[ValidAnswer], labels: Sequence[str]) -> float | None:
    if not valid:
        return None
    scores: list[float] = []
    for answer in valid:
        probabilities = dict(answer.probabilities)
        if set(probabilities) != set(labels):
            raise SchemaError("probabilities: labels do not match the question")
        scores.append(
            math.fsum(
                (probabilities[label] - (1.0 if label == answer.gold else 0.0)) ** 2
                for label in labels
            )
        )
    return math.fsum(scores) / len(scores)


def usage_from_body(body: str | None) -> tuple[int, int] | None:
    """``(input_tokens, output_tokens)`` from a valid Jev body, or ``None`` when absent."""
    if body is None:
        return None
    try:
        value = strict_json_loads(body)
    except SchemaError:
        return None
    if type(value) is not dict or type(value.get("usage")) is not dict:
        return None
    usage = value["usage"]
    counts = (usage.get("input_tokens"), usage.get("output_tokens"))
    if any(type(count) is not int for count in counts):
        return None
    return (counts[0], counts[1])


def cohort_summary(
    cohort: str,
    scheduled: int,
    records: Sequence[CohortRecord],
    *,
    started_without_capture: int,
    unattempted: int,
    labels: Sequence[str],
) -> dict[str, object]:
    """Counts, failure categories, decisions and the descriptive metrics for one cohort."""
    captured = len(records)
    if captured + started_without_capture + unattempted != scheduled:
        raise SchemaError("cohort: partition does not account for every scheduled case")
    complete = captured == scheduled
    valid = valid_answers(records)
    failures = Counter(
        record.outcome.code for record in records if not isinstance(record.outcome, ChoiceAnswer)
    )
    decisions = Counter(record.decision.action for record in records)
    act = decisions["ACT"]
    wrong_act = sum(
        1
        for record in records
        if record.decision.action == "ACT" and record.decision.choice != record.case.expected_label
    )
    usages = [usage for usage in (usage_from_body(r.capture.body_json) for r in records) if usage]
    return {
        "cohort": cohort,
        "scheduled": scheduled,
        "captured": captured,
        "started_without_capture": started_without_capture,
        "unattempted": unattempted,
        "complete": complete,
        "partial_metrics": not complete,
        "valid_answers": len(valid),
        "failures": dict(sorted(failures.items())),
        "decisions": {action: decisions[action] for action in _ACTIONS},
        "act": act,
        "wrong_act": wrong_act,
        "coverage": act / scheduled if complete else None,
        "accepted_error": wrong_act / act if complete and act else None,
        "reliability_bins": reliability_bins(valid),
        "ece": ece(valid),
        "brier": brier(valid, labels),
        "usage": {
            "captures_with_usage": len(usages),
            "input_tokens": sum(u[0] for u in usages) if usages else None,
            "output_tokens": sum(u[1] for u in usages) if usages else None,
            "monetary": None,
        },
    }
