"""Durable attempt journal and its strict partition into captured / started / unattempted.

The journal is an append-only JSONL file. Each line is one canonical JSON
object plus LF, written and ``fsync``ed before the collector continues. Four
kinds exist, each with an EXACT field set:

* ``budget_start`` once, as the first entry, before the first request:
  ``budget_seconds`` (the frozen preregistered budget), canonical UTC
  ``start_utc`` and ``deadline_utc`` (start plus budget);
* ``attempt_start`` immediately before each ``decide`` call: the schedule
  binding, canonical UTC ``started_utc`` and ``monotonic_s``;
* ``capture`` immediately after it: the schedule binding, the capture
  verbatim (raw body included, even when malformed), ``monotonic_s`` and
  ``late``;
* ``run_end`` once, when the collector stopped: ``monotonic_s``, ``stopped``
  (``complete`` or ``budget_exceeded``) and ``budget_exceeded``.

Every entry is bound to the run id, the preregistration digest, the sequence
number, the cohort, the case id and the request hash; a capture's nested
``request_sha256`` must also equal the scheduled request hash. No entry
carries credentials, headers or anything from the environment. Entries exist
only when an attempt starts or a capture arrives: a missing capture stays
missing.

``partition`` replays the complete rows against the frozen schedule and
REJECTS (``JournalError``) anything that is not the sequential single-attempt
protocol: unknown or extra fields, wrong types (booleans are not integers),
non-canonical UTC strings, a budget other than the preregistered one, a
deadline that is not start plus budget, nonfinite, negative or
non-chronological monotonic values, a request started at or after the
cutoff, a ``late`` flag that contradicts the recorded times, a ``run_end``
whose ``stopped``/``budget_exceeded`` contradict the recorded captures and
schedule, a second attempt for an open case, a capture without its attempt,
a capture whose nested request hash is not the scheduled one, any entry
after ``run_end``, or attempts without a ``budget_start`` first. A journal
that shows a retry or a contradiction is evidence of a protocol violation,
not data to repair.

Torn tail: an ``fsync``-per-entry writer can leave at most one unterminated
final fragment after a crash. ``read_journal`` returns the complete rows and
that raw fragment separately; the file is never modified, the fragment is
never parsed into a record, and the receipt layer turns it into an explicit
ERROR reason while accounting only for the validated complete prefix. A
complete (LF-terminated) row that does not parse is a strict error.

Evidence limits: recorded wall-clock strings and monotonic offsets are what
the collector wrote. They prove neither real elapsed time nor that any
inference occurred; they only have to be internally coherent.
"""

from __future__ import annotations

import math
import os
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Final, Protocol

from actseal.errors import SchemaError
from actseal.records import CapturedOutcome
from actseal.serialization import (
    MAX_JSON_BYTES,
    canonical_json,
    from_data,
    strict_json_loads,
    to_data,
)
from jev_audit.protocol import ScheduleEntry

__all__ = [
    "JOURNAL_FILE",
    "UTC_FORMAT",
    "Captured",
    "FileJournal",
    "Journal",
    "JournalError",
    "JournalRows",
    "Partition",
    "attempt_entry",
    "budget_entry",
    "capture_entry",
    "deadline_utc",
    "end_entry",
    "parse_utc",
    "partition",
    "read_journal",
]

JOURNAL_FILE: Final = "journal.jsonl"
#: The only accepted UTC form: ``YYYY-MM-DDTHH:MM:SSZ``.
UTC_FORMAT: Final = "%Y-%m-%dT%H:%M:%SZ"
_UTC_PATTERN: Final = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z")
_LF: Final = b"\n"
_MODE: Final = 0o644
_BINDING_FIELDS: Final[frozenset[str]] = frozenset(
    {"kind", "run_id", "preregistration_sha256", "sequence", "cohort", "case_id", "request_sha256"}
)
_FIELDS: Final[Mapping[str, frozenset[str]]] = {
    "budget_start": frozenset(
        {"kind", "run_id", "preregistration_sha256", "budget_seconds", "start_utc", "deadline_utc"}
    ),
    "attempt_start": _BINDING_FIELDS | {"started_utc", "monotonic_s"},
    "capture": _BINDING_FIELDS | {"capture", "monotonic_s", "late"},
    "run_end": frozenset(
        {"kind", "run_id", "preregistration_sha256", "monotonic_s", "stopped", "budget_exceeded"}
    ),
}
_STOPPED: Final[frozenset[str]] = frozenset({"complete", "budget_exceeded"})


class JournalError(Exception):
    """The journal violates the sequential single-attempt protocol or its record shapes."""


class Journal(Protocol):
    def append(self, entry: Mapping[str, object]) -> None: ...


class FileJournal:
    """Append-only, exclusive-create, fsync-per-entry journal file."""

    def __init__(self, path: Path) -> None:
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_APPEND | os.O_CLOEXEC
        self._fd: int | None = os.open(path, flags, _MODE)

    def append(self, entry: Mapping[str, object]) -> None:
        if self._fd is None:
            raise JournalError("journal: closed")
        data = canonical_json(dict(entry)) + _LF
        view = memoryview(data)
        while view:
            written = os.write(self._fd, view)
            view = view[written:]
        os.fsync(self._fd)

    def close(self) -> None:
        if self._fd is not None:
            os.close(self._fd)
            self._fd = None


# --------------------------------------------------------------------------- #
# UTC helpers
# --------------------------------------------------------------------------- #


def parse_utc(text: object, field: str) -> datetime:
    """Parse the canonical UTC form; anything else (including other ISO forms) is rejected."""
    if type(text) is not str or _UTC_PATTERN.fullmatch(text) is None:
        raise JournalError(f"{field}: must be canonical UTC YYYY-MM-DDTHH:MM:SSZ")
    try:
        parsed = datetime.strptime(text, UTC_FORMAT).replace(tzinfo=UTC)
    except ValueError:
        raise JournalError(f"{field}: must be a valid UTC instant") from None
    if parsed.strftime(UTC_FORMAT) != text:
        raise JournalError(f"{field}: must be canonical UTC")
    return parsed


def deadline_utc(start_utc: str, budget_seconds: int) -> str:
    """``start_utc`` plus the budget in canonical form; a date past year 9999 is a journal error."""
    start = parse_utc(start_utc, "start_utc")
    try:
        deadline = start + timedelta(seconds=budget_seconds)
    except OverflowError:
        raise JournalError("deadline_utc: start_utc plus the budget is out of range") from None
    return deadline.strftime(UTC_FORMAT)


# --------------------------------------------------------------------------- #
# Entry constructors (the collector writes exactly these shapes)
# --------------------------------------------------------------------------- #


def _binding(
    kind: str, run_id: str, preregistration_sha256: str, entry: ScheduleEntry
) -> dict[str, object]:
    return {
        "kind": kind,
        "run_id": run_id,
        "preregistration_sha256": preregistration_sha256,
        "sequence": entry.sequence,
        "cohort": entry.cohort,
        "case_id": entry.case.case_id,
        "request_sha256": entry.request_sha256,
    }


def budget_entry(
    run_id: str,
    preregistration_sha256: str,
    *,
    budget_seconds: int,
    start_utc: str,
    deadline_utc: str,
) -> dict[str, object]:
    return {
        "kind": "budget_start",
        "run_id": run_id,
        "preregistration_sha256": preregistration_sha256,
        "budget_seconds": budget_seconds,
        "start_utc": start_utc,
        "deadline_utc": deadline_utc,
    }


def attempt_entry(
    run_id: str,
    preregistration_sha256: str,
    entry: ScheduleEntry,
    *,
    started_utc: str,
    monotonic_s: float,
) -> dict[str, object]:
    data = _binding("attempt_start", run_id, preregistration_sha256, entry)
    data["started_utc"] = started_utc
    data["monotonic_s"] = monotonic_s
    return data


def capture_entry(
    run_id: str,
    preregistration_sha256: str,
    entry: ScheduleEntry,
    capture: CapturedOutcome,
    *,
    monotonic_s: float,
    late: bool,
) -> dict[str, object]:
    data = _binding("capture", run_id, preregistration_sha256, entry)
    data["capture"] = to_data(capture)
    data["monotonic_s"] = monotonic_s
    data["late"] = late
    return data


def end_entry(
    run_id: str,
    preregistration_sha256: str,
    *,
    monotonic_s: float,
    stopped: str,
    budget_exceeded: bool,
) -> dict[str, object]:
    return {
        "kind": "run_end",
        "run_id": run_id,
        "preregistration_sha256": preregistration_sha256,
        "monotonic_s": monotonic_s,
        "stopped": stopped,
        "budget_exceeded": budget_exceeded,
    }


# --------------------------------------------------------------------------- #
# Reading
# --------------------------------------------------------------------------- #


@dataclass(frozen=True, slots=True)
class JournalRows:
    """Complete (LF-terminated, strictly decoded) rows plus any raw unterminated tail."""

    rows: tuple[Mapping[str, object], ...]
    torn_tail: bytes | None


def read_journal(path: Path) -> JournalRows:
    """Strictly decode every terminated row; keep an unterminated final fragment as raw bytes.

    The file is read, never rewritten. A terminated row that is not valid
    UTF-8, not strict JSON or not an object with a string ``kind`` is a
    :class:`JournalError`: only the final unterminated fragment may be torn.
    """
    with path.open("rb") as stream:
        data = stream.read(MAX_JSON_BYTES + 1)
    if len(data) > MAX_JSON_BYTES:
        raise JournalError(f"journal: file exceeds {MAX_JSON_BYTES} bytes")
    pieces = data.split(_LF)
    tail = pieces.pop()
    torn_tail = tail if tail else None
    entries: list[Mapping[str, object]] = []
    for index, raw in enumerate(pieces):
        try:
            value = strict_json_loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, SchemaError) as exc:
            raise JournalError(f"journal[{index}]: {exc}") from None
        if type(value) is not dict or type(value.get("kind")) is not str:
            raise JournalError(f"journal[{index}]: expected an object with a kind")
        entries.append(value)
    return JournalRows(tuple(entries), torn_tail)


# --------------------------------------------------------------------------- #
# Partition
# --------------------------------------------------------------------------- #


@dataclass(frozen=True, slots=True)
class Captured:
    entry: ScheduleEntry
    capture: CapturedOutcome
    monotonic_s: float
    late: bool


@dataclass(frozen=True, slots=True)
class Partition:
    """All scheduled entries, each in exactly one of the three classes, plus validated metadata."""

    budget: Mapping[str, object] | None
    captured: tuple[Captured, ...]
    started_without_capture: tuple[ScheduleEntry, ...]
    unattempted: tuple[ScheduleEntry, ...]
    ended: Mapping[str, object] | None

    @property
    def budget_exceeded(self) -> bool:
        """Derived from recorded times and the validated stop reason, never from a bare flag."""
        return any(item.late for item in self.captured) or (
            self.ended is not None and self.ended.get("stopped") == "budget_exceeded"
        )


def _fail(index: int, message: str) -> JournalError:
    return JournalError(f"journal[{index}]: {message}")


def _check_fields(row: Mapping[str, object], index: int) -> str:
    kind = row.get("kind")
    if type(kind) is not str or kind not in _FIELDS:
        raise _fail(index, "unknown entry kind")
    if set(row) != _FIELDS[kind]:
        raise _fail(index, f"{kind} must have exactly its declared fields")
    return kind


def _check_bound(row: Mapping[str, object], index: int, entry: ScheduleEntry) -> None:
    expected = {
        "sequence": entry.sequence,
        "cohort": entry.cohort,
        "case_id": entry.case.case_id,
        "request_sha256": entry.request_sha256,
    }
    for key, value in expected.items():
        if type(row.get(key)) is not type(value) or row.get(key) != value:
            raise _fail(index, f"{key} does not match the schedule")


def _monotonic(row: Mapping[str, object], index: int, previous: float) -> float:
    value = row.get("monotonic_s")
    if type(value) is bool or not isinstance(value, int | float):
        raise _fail(index, "monotonic_s must be a number")
    try:
        number = float(value)
    except OverflowError:  # an integer too large for a float is not a finite time
        raise _fail(index, "monotonic_s must be finite and nonnegative") from None
    if not math.isfinite(number) or number < 0.0:
        raise _fail(index, "monotonic_s must be finite and nonnegative")
    if number < previous:
        raise _fail(index, "monotonic_s must not decrease")
    return number


def _check_budget(row: Mapping[str, object], index: int, budget_seconds: int) -> None:
    declared = row.get("budget_seconds")
    if type(declared) is not int or declared != budget_seconds:
        raise _fail(index, "budget_seconds must be the preregistered budget")
    start = row.get("start_utc")
    parse_utc(start, f"journal[{index}].start_utc")
    if not isinstance(start, str):  # pragma: no cover - parse_utc rejected it
        raise _fail(index, "start_utc must be a string")
    if row.get("deadline_utc") != deadline_utc(start, budget_seconds):
        raise _fail(index, "deadline_utc must be start_utc plus the budget")


def _check_end(
    row: Mapping[str, object],
    index: int,
    *,
    monotonic: float,
    complete: bool,
    any_late: bool,
    budget_seconds: int,
) -> None:
    stopped = row.get("stopped")
    if type(stopped) is not str or stopped not in _STOPPED:
        raise _fail(index, "stopped must be complete or budget_exceeded")
    if (stopped == "complete") != complete:
        raise _fail(index, "stopped contradicts the number of captured cases")
    if stopped == "budget_exceeded" and monotonic < budget_seconds:
        raise _fail(index, "budget_exceeded stop recorded before the budget was spent")
    flag = row.get("budget_exceeded")
    if type(flag) is not bool or flag != (stopped == "budget_exceeded" or any_late):
        raise _fail(index, "budget_exceeded contradicts the recorded times")


def partition(
    rows: Sequence[Mapping[str, object]],
    schedule: Sequence[ScheduleEntry],
    *,
    run_id: str,
    preregistration_sha256: str,
    budget_seconds: int,
) -> Partition:
    """Replay complete rows against the schedule under the strict protocol described above."""
    budget: Mapping[str, object] | None = None
    ended: Mapping[str, object] | None = None
    captured: list[Captured] = []
    started: ScheduleEntry | None = None
    started_at = 0.0
    previous = 0.0
    position = 0
    for index, row in enumerate(rows):
        kind = _check_fields(row, index)
        if ended is not None:
            raise _fail(index, "entry after run_end")
        if (
            row.get("run_id") != run_id
            or row.get("preregistration_sha256") != preregistration_sha256
        ):
            raise _fail(index, "not bound to this run and preregistration")
        if kind == "budget_start":
            if index != 0:
                raise _fail(index, "budget_start must be the first entry")
            _check_budget(row, index, budget_seconds)
            budget = row
            continue
        if budget is None:
            raise _fail(index, "attempts require a budget_start first")
        previous = _monotonic(row, index, previous)
        if kind == "attempt_start":
            if started is not None or position >= len(schedule):
                raise _fail(index, "attempt without a terminal capture before it")
            _check_bound(row, index, schedule[position])
            parse_utc(row.get("started_utc"), f"journal[{index}].started_utc")
            if previous >= budget_seconds:
                raise _fail(index, "a request cannot start at or after the budget cutoff")
            started = schedule[position]
            started_at = previous
        elif kind == "capture":
            if started is None:
                raise _fail(index, "capture without an attempt_start")
            _check_bound(row, index, started)
            try:
                capture = from_data(CapturedOutcome, row.get("capture"))
            except SchemaError as exc:
                raise _fail(index, f"capture: {exc}") from None
            if capture.request_sha256 != started.request_sha256:
                raise _fail(index, "capture.request_sha256 does not match the scheduled request")
            if previous < started_at:  # pragma: no cover - _monotonic already forbids it
                raise _fail(index, "capture before its attempt")
            late = row.get("late")
            if type(late) is not bool or late != (previous > budget_seconds):
                raise _fail(index, "late contradicts the recorded monotonic time")
            captured.append(Captured(started, capture, previous, late))
            started = None
            position += 1
        else:  # run_end
            if started is not None:
                raise _fail(index, "run_end while an attempt is open")
            _check_end(
                row,
                index,
                monotonic=previous,
                complete=position == len(schedule),
                any_late=any(item.late for item in captured),
                budget_seconds=budget_seconds,
            )
            ended = row
    remaining = list(schedule[position:])
    started_without_capture = (remaining.pop(0),) if started is not None else ()
    return Partition(budget, tuple(captured), started_without_capture, tuple(remaining), ended)
