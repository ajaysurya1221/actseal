"""Offline reconstruction of a run directory, artifact writing and receipt checking.

A run directory holds ``run.json``, ``inputs/`` (byte copies of the
preregistration data), ``journal.jsonl`` and, after finalization, the
calibration sidecar, the audit receipt and, ONLY when every verification case
was captured, the ordinary seven-file evidence bundle under ``evidence/``.

``reconstruct`` recomputes everything from the inputs and the journal with
the frozen product authorities (``normalize``, ``evaluate``,
``run_fault_campaign``, ``assess``): every captured outcome and decision, the
strict partition of the scheduled entries, both cohort summaries, the
verification verdict when its inventory is complete, and the exact sidecar
and receipt documents. ``write_artifacts`` writes those documents (and the
bundle through ``write_bundle``) as new files; ``check_run`` recomputes them
again and compares byte for byte, replays the bundle offline and reports
every difference. Nothing here imports a transport, opens a socket, reads a
key or fetches a missing response.

Strictness (REVIEW 06): ``run.json`` must have exactly its declared fields
with the supported schema version, hex identifiers, a dotted interpreter
version and a canonical UTC creation time. The journal is validated by
``jev_audit.journal.partition`` (exact record shapes, frozen budget,
chronology, nested request binding, coherent flags); any violation is a
``JournalError`` and the run cannot be finalized or declared consistent. A
torn (unterminated) final journal fragment is not a record: the validated
complete prefix is accounted for, the fragment is reported as the reason
``journal_torn_tail``, nothing is invented and the receipt is ``ERROR``.

The audit receipt is ``COMPLETE`` only when all scheduled cases were captured
under a valid budget, no attempt is open, the run ended without a torn tail
and the budget was not exceeded; otherwise ``ERROR`` with sorted reasons.
Budget status is derived from the recorded monotonic times and the validated
stop reason, never from a bare flag. A complete verification bundle keeps its
independently computed verdict regardless of the receipt status.

Checker snapshot: a receipt is checked against the scripts whose hashes the
preregistration binds and the producer implementation recorded in the lock.
Script drift and producer drift are reported explicitly (``checker`` block,
findings) and are never suppressed; a different producer implementation
fails the shared lock validation unless Task 19 registers it. Generic
final-release replay of the ordinary bundle is Task 19's separate gate and
does not validate the benchmark journal.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Final

from actseal.assessment import assess
from actseal.contract import read_input_text
from actseal.errors import ActsealError, SchemaError
from actseal.evidence import write_bundle
from actseal.faults import run_fault_campaign
from actseal.normalization import normalize
from actseal.policy import evaluate
from actseal.records import DecisionRecord, EvidenceBundle, Verdict
from actseal.replay import replay
from actseal.serialization import canonical_json, strict_json_loads, to_data
from jev_audit.journal import (
    JOURNAL_FILE,
    Captured,
    JournalError,
    Partition,
    parse_utc,
    partition,
    read_journal,
)
from jev_audit.metrics import CohortRecord, cohort_summary
from jev_audit.protocol import BUDGET_SECONDS, Verified, verify_preregistration

__all__ = [
    "EVIDENCE_DIR",
    "INPUTS_DIR",
    "RECEIPT_FILE",
    "RECEIPT_SCHEMA",
    "RUN_FILE",
    "RUN_SCHEMA",
    "SCHEMA_VERSION",
    "SIDECAR_FILE",
    "SIDECAR_SCHEMA",
    "Reconstruction",
    "check_run",
    "finalize",
    "load_run",
    "reconstruct",
    "write_artifacts",
]

RUN_FILE: Final = "run.json"
INPUTS_DIR: Final = "inputs"
EVIDENCE_DIR: Final = "evidence"
SIDECAR_FILE: Final = "calibration_sidecar.json"
RECEIPT_FILE: Final = "audit_receipt.json"
RUN_SCHEMA: Final = "actseal-jev-audit-run"
SIDECAR_SCHEMA: Final = "actseal-jev-audit-calibration-sidecar"
RECEIPT_SCHEMA: Final = "actseal-jev-audit-receipt"
SCHEMA_VERSION: Final = 1
_RUN_KEYS: Final[frozenset[str]] = frozenset(
    {
        "schema",
        "schema_version",
        "run_id",
        "preregistration_sha256",
        "lock_sha256",
        "scheduled",
        "python_version",
        "created_utc",
    }
)
_SHA256_HEX: Final = re.compile(r"[0-9a-f]{64}")
_RUN_ID_HEX: Final = re.compile(r"[0-9a-f]{32}")
_PYTHON_VERSION: Final = re.compile(r"\d+\.\d+\.\d+")
#: Preregistration findings a checker reports but does not treat as fatal.
_REPORTED_PREFIXES: Final = ("preregistration: differs", "producer: lock fingerprint")
_LF: Final = b"\n"


@dataclass(frozen=True, slots=True)
class Reconstruction:
    run: Mapping[str, object]
    verified: Verified
    partition: Partition
    torn_tail: bytes | None
    calibration: tuple[CohortRecord, ...]
    verification: tuple[CohortRecord, ...]
    summaries: dict[str, dict[str, object]]
    bundle: EvidenceBundle | None
    sidecar: dict[str, object]
    receipt: dict[str, object]
    reported: tuple[str, ...]

    @property
    def verdict(self) -> Verdict | None:
        return None if self.bundle is None else self.bundle.verdict


def load_run(run_dir: Path) -> Mapping[str, object]:
    """Strictly decode ``run.json``: exact fields, supported schema, typed metadata."""
    value = strict_json_loads(read_input_text(run_dir / RUN_FILE))
    if type(value) is not dict or set(value) != _RUN_KEYS:
        raise ActsealError("run.json: unexpected document shape")
    if value["schema"] != RUN_SCHEMA:
        raise ActsealError("run.json: unsupported schema")
    version = value["schema_version"]
    if type(version) is not int or version != SCHEMA_VERSION:
        raise ActsealError("run.json: unsupported schema version")
    for key, pattern in (
        ("run_id", _RUN_ID_HEX),
        ("preregistration_sha256", _SHA256_HEX),
        ("lock_sha256", _SHA256_HEX),
        ("python_version", _PYTHON_VERSION),
    ):
        text = value[key]
        if type(text) is not str or pattern.fullmatch(text) is None:
            raise ActsealError(f"run.json: {key} is malformed")
    scheduled = value["scheduled"]
    if type(scheduled) is not int or scheduled < 1:
        raise ActsealError("run.json: scheduled must be a positive integer")
    try:
        parse_utc(value["created_utc"], "created_utc")
    except JournalError as exc:
        raise ActsealError(f"run.json: {exc}") from None
    return value


def _records(
    verified: Verified, captured: tuple[Captured, ...], cohort: str
) -> tuple[CohortRecord, ...]:
    question = verified.lock.contract.question
    identity = verified.lock.model_identity
    policy = verified.lock.contract.policy
    records: list[CohortRecord] = []
    for item in captured:
        if item.entry.cohort != cohort:
            continue
        outcome = normalize(item.capture, question, identity)
        records.append(
            CohortRecord(item.entry.case, item.capture, outcome, evaluate(outcome, policy))
        )
    return tuple(records)


def _count(entries: tuple[object, ...], cohort: str) -> int:
    return sum(1 for entry in entries if getattr(entry, "cohort", None) == cohort)


def _reasons(part: Partition, scheduled: int, torn_tail: bytes | None) -> set[str]:
    reasons: set[str] = set()
    if len(part.captured) != scheduled:
        reasons.add("incomplete_collection")
    if part.started_without_capture:
        reasons.add("started_without_capture")
    if part.ended is None:
        reasons.add("journal_not_ended")
    if part.budget is None and (part.captured or part.ended is not None):  # pragma: no cover
        reasons.add("budget_missing")  # partition already rejects attempts without a budget
    if part.budget_exceeded:
        reasons.add("budget_exceeded")
    if torn_tail is not None:
        reasons.add("journal_torn_tail")
    return reasons


def reconstruct(run_dir: Path, *, scripts: Mapping[str, str] | None = None) -> Reconstruction:
    """Recompute every artifact of ``run_dir`` from its inputs and journal alone."""
    run = load_run(run_dir)
    python_version = run["python_version"]
    if not isinstance(python_version, str):  # pragma: no cover - load_run checked it
        raise ActsealError("run.json: python_version must be a string")
    verified = verify_preregistration(
        run_dir / INPUTS_DIR, source_dir=None, scripts=scripts, python_version=python_version
    )
    fatal = [f for f in verified.findings if not f.startswith(_REPORTED_PREFIXES)]
    if fatal:
        raise ActsealError("inputs: " + "; ".join(fatal))
    reported = tuple(f for f in verified.findings if f.startswith(_REPORTED_PREFIXES))
    run_id = run["run_id"]
    if (
        not isinstance(run_id, str)
        or run["preregistration_sha256"] != verified.preregistration_sha256
    ):
        raise ActsealError("run.json: not bound to the preregistration in inputs/")
    if run["lock_sha256"] != verified.lock.sha256 or run["scheduled"] != len(verified.entries):
        raise ActsealError("run.json: lock digest or schedule size differs from inputs/")
    journal_path = run_dir / JOURNAL_FILE
    rows: tuple[Mapping[str, object], ...] = ()
    torn_tail: bytes | None = None
    if journal_path.exists():
        journal = read_journal(journal_path)
        rows, torn_tail = journal.rows, journal.torn_tail
    part = partition(
        rows,
        verified.entries,
        run_id=run_id,
        preregistration_sha256=verified.preregistration_sha256,
        budget_seconds=BUDGET_SECONDS,
    )
    labels = verified.lock.contract.question.labels
    cohorts: dict[str, dict[str, object]] = {}
    records_by_cohort: dict[str, tuple[CohortRecord, ...]] = {}
    for cohort, scheduled in (
        ("calibration", len(verified.calibration_cases)),
        ("verification", len(verified.lock.verification_cases)),
    ):
        records = _records(verified, part.captured, cohort)
        records_by_cohort[cohort] = records
        cohorts[cohort] = cohort_summary(
            cohort,
            scheduled,
            records,
            started_without_capture=_count(part.started_without_capture, cohort),
            unattempted=_count(part.unattempted, cohort),
            labels=labels,
        )
    bundle = _verification_bundle(verified, records_by_cohort["verification"])
    reasons = _reasons(part, len(verified.entries), torn_tail)
    sidecar: dict[str, object] = {
        "schema": SIDECAR_SCHEMA,
        "schema_version": SCHEMA_VERSION,
        "run_id": run_id,
        "preregistration_sha256": verified.preregistration_sha256,
        "lock_sha256": verified.lock.sha256,
        "cohort": "calibration",
        "complete": cohorts["calibration"]["complete"],
        "records": [
            to_data(DecisionRecord(r.case.case_id, r.capture, r.outcome, r.decision))
            for r in records_by_cohort["calibration"]
        ],
        "summary": cohorts["calibration"],
    }
    receipt: dict[str, object] = {
        "schema": RECEIPT_SCHEMA,
        "schema_version": SCHEMA_VERSION,
        "run_id": run_id,
        "preregistration_sha256": verified.preregistration_sha256,
        "lock_sha256": verified.lock.sha256,
        "status": "COMPLETE" if not reasons else "ERROR",
        "reasons": sorted(reasons),
        "scheduled": len(verified.entries),
        "partition": {
            "captured": len(part.captured),
            "started_without_capture": len(part.started_without_capture),
            "unattempted": len(part.unattempted),
        },
        "journal": {
            "complete_rows": len(rows),
            "torn_tail_bytes": None if torn_tail is None else len(torn_tail),
        },
        "budget": {
            "recorded": None if part.budget is None else dict(part.budget),
            "exceeded": part.budget_exceeded,
            "late_captures": sum(1 for item in part.captured if item.late),
            "ended": None if part.ended is None else dict(part.ended),
            "note": (
                "recorded clocks are what the collector wrote; they prove neither real "
                "elapsed time nor that inference occurred"
            ),
        },
        "cohorts": cohorts,
        "verification_bundle": {
            "written": bundle is not None,
            "path": EVIDENCE_DIR if bundle is not None else None,
            "verdict": None if bundle is None else to_data(bundle.verdict),
        },
        "spend": {
            "input_tokens": _total(cohorts, "input_tokens"),
            "output_tokens": _total(cohorts, "output_tokens"),
            "monetary": None,
            "note": "token totals come only from captured valid bodies; credit change unmeasured",
        },
        "calibration_sidecar": SIDECAR_FILE,
    }
    return Reconstruction(
        run,
        verified,
        part,
        torn_tail,
        records_by_cohort["calibration"],
        records_by_cohort["verification"],
        cohorts,
        bundle,
        sidecar,
        receipt,
        reported,
    )


def _total(cohorts: Mapping[str, Mapping[str, object]], key: str) -> int | None:
    values: list[int] = []
    for summary in cohorts.values():
        usage = summary["usage"]
        if isinstance(usage, Mapping) and isinstance(usage.get(key), int):
            values.append(usage[key])
    return sum(values) if values else None


def _verification_bundle(
    verified: Verified, records: tuple[CohortRecord, ...]
) -> EvidenceBundle | None:
    """The ordinary bundle, only for a complete verification inventory; never a reduced one."""
    lock = verified.lock
    if len(records) != len(lock.verification_cases):
        return None
    decision_records = tuple(
        DecisionRecord(r.case.case_id, r.capture, r.outcome, r.decision) for r in records
    )
    faults = run_fault_campaign(lock)
    verdict = assess(decision_records, lock, faults)
    return EvidenceBundle(
        lock,
        verified.calibration_text,
        verified.verification_text,
        decision_records,
        faults,
        verdict,
    )


def _write_new(path: Path, data: bytes) -> None:
    with path.open("xb") as stream:
        stream.write(data)


def write_artifacts(run_dir: Path, recon: Reconstruction) -> Path:
    """Write the sidecar, the receipt and (complete verification only) the bundle as new files."""
    receipt_path = run_dir / RECEIPT_FILE
    if receipt_path.exists() or (run_dir / SIDECAR_FILE).exists():
        raise FileExistsError("run: artifacts already exist; a finalized run is never rewritten")
    _write_new(run_dir / SIDECAR_FILE, canonical_json(recon.sidecar) + _LF)
    if recon.bundle is not None:
        write_bundle(recon.bundle, run_dir / EVIDENCE_DIR)
    _write_new(receipt_path, canonical_json(recon.receipt) + _LF)
    return receipt_path


def finalize(run_dir: Path) -> Path:
    """Reconstruct a run from its journal and write its artifacts (recovery after a crash too)."""
    return write_artifacts(run_dir, reconstruct(run_dir))


def _compare(run_dir: Path, name: str, expected: bytes, findings: list[str]) -> None:
    path = run_dir / name
    if not path.exists():
        findings.append(f"{name}: missing")
    elif path.read_bytes() != expected:
        findings.append(f"{name}: differs from the offline reconstruction")


def check_run(run_dir: Path, *, scripts: Mapping[str, str] | None = None) -> dict[str, object]:
    """Recompute everything offline and compare with the written artifacts; report differences."""
    recon = reconstruct(run_dir, scripts=scripts)
    findings: list[str] = list(recon.reported)
    _compare(run_dir, SIDECAR_FILE, canonical_json(recon.sidecar) + _LF, findings)
    _compare(run_dir, RECEIPT_FILE, canonical_json(recon.receipt) + _LF, findings)
    evidence = run_dir / EVIDENCE_DIR
    replayed: Verdict | None = None
    if recon.bundle is not None:
        if not evidence.exists():
            findings.append("evidence: missing for a complete verification cohort")
        else:
            try:
                replayed = replay(evidence, expected_lock_sha256=recon.verified.lock.sha256)
            except SchemaError as exc:
                findings.append(f"evidence: {exc}")
            if replayed is not None and replayed != recon.bundle.verdict:
                findings.append("evidence: offline replay does not reproduce the verdict")
    elif evidence.exists():
        findings.append("evidence: a bundle exists although verification is incomplete")
    receipt = recon.receipt
    return {
        "run_dir": str(run_dir),
        "consistent": not findings,
        "findings": findings,
        "audit_status": receipt["status"],
        "reasons": receipt["reasons"],
        "partition": receipt["partition"],
        "journal": receipt["journal"],
        "checker": {
            "scripts_match_preregistration": not any("scripts" in f for f in recon.reported),
            "producer_is_running_implementation": not any(
                f.startswith("producer:") for f in recon.reported
            ),
            "note": (
                "full receipt checking is pinned to the preregistered scripts and the "
                "recorded producer; drift is reported, never suppressed; generic bundle "
                "replay under a later release is Task 19's separate gate"
            ),
        },
        "verification_verdict": None if replayed is None else to_data(replayed),
        "cohorts": {
            name: {k: summary[k] for k in ("captured", "valid_answers", "act", "wrong_act")}
            for name, summary in recon.summaries.items()
        },
    }
