# Jev audit benchmark (experimental; plan/v1 Task 06)

This directory is a benchmark harness, not part of the `actseal` package or
its 1.x stability promise. It reuses the frozen product authorities (records,
contract parsing, locking, normalization, policy, faults, assessment, evidence
and replay) and adds only what the preregistered audit needs. Nothing here is
reachable from the stable `actseal` command line.

## Commands

```bash
uv run --frozen python bench/jev_audit/run.py --write-preregistration --data DIR [--source DIR]
uv run --frozen python bench/jev_audit/run.py --check-preregistration [--source DIR]
uv run --frozen python bench/jev_audit/run.py --execute --out RUN_DIR [--source DIR]
uv run --frozen python bench/jev_audit/run.py --finalize RUN_DIR
uv run --frozen python bench/jev_audit/run.py --check-receipts RUN_DIR
```

`--execute` requires the already exported `JEV_API_KEY`, the hash-verified
source cache and a passing preregistration check. It makes one request per
scheduled case under the preregistered 90-minute monotonic budget and never
prints, journals or echoes the key. A passing `--check-preregistration` is a
consistency statement only: collection requires Codex's recorded review of
the committed preregistration and a separate live-phase dispatch.

## Preregistration candidates

| Directory | Status | Notes |
|---|---|---|
| `data/` | historical (commit `e466d9e`) | first candidate; bytes preserved unchanged, never active again |
| `data-revision2/` | historical (commit `47f184f`) | after the REVIEW 06 journal repair; bytes preserved unchanged, never active again |
| `data-revision3/` | active (`protocol.DATA_DIR`) | after the V1-038 overflow guards; same inputs, contract, lock, license and attribution; only the bound script hashes and self-seal differ |

A candidate is regenerated only when the bound scripts change. Inputs,
contract, lock, selection, order, identity and thresholds never change in a
revision; no observation exists for either candidate. Neither candidate is
approved for live work until an independent review records it.

## Checker and producer snapshot

A run directory records the preregistration it ran under (`inputs/`), which
binds the SHA-256 of every script in this directory and the producer
implementation fingerprint in the lock. `--check-receipts` recomputes every
artifact with the CURRENT scripts and compares them with the recorded ones:

- script drift is reported as a finding (`checker.scripts_match_preregistration`
  false); the recorded hashes identify the exact checker snapshot to use;
- producer drift (a different `actseal` source fingerprint) fails the shared
  lock validation unless Task 19 registers the producer; it is never
  suppressed here;
- generic replay of the ordinary `evidence/` bundle under a later release is
  Task 19's separate compatibility gate and does not validate the benchmark
  journal, sidecar or receipt.

Historical runs are never deleted, resealed or rewritten. A started run
directory is refused by `--execute`; a finalized run refuses a second
`--finalize`.

## Journal and receipt semantics

The journal is append-only, `fsync`ed per entry, with exact record shapes:
`budget_start` (frozen 5400 s budget, canonical UTC start and deadline),
`attempt_start` before each request, `capture` after it (raw body preserved,
nested request hash bound to the schedule), `run_end`. The checker rejects
unknown fields or kinds, wrong types, non-canonical UTC, a budget other than
the preregistered one, non-chronological or nonfinite times, a request
started at or after the cutoff, flags that contradict recorded times, retries,
captures without attempts and entries after `run_end`.

An unterminated final fragment (a torn write) is kept as raw bytes, reported
as `journal_torn_tail`, and the validated complete prefix is accounted for; no
capture is invented and the receipt is `ERROR`. The receipt partitions every
scheduled case into captured, started-without-capture and unattempted. It is
`COMPLETE` only when every case was captured under a valid budget, the run
ended and the budget was not exceeded. A complete verification cohort
produces the ordinary seven-file bundle and keeps its own verdict regardless
of the receipt status; calibration stays in a separate sidecar.

Recorded clocks are what the collector wrote. They prove neither real elapsed
time nor that any inference occurred; only internal coherence is checked.
