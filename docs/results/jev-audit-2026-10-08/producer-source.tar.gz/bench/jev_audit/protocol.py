"""The frozen audit protocol and its preregistration document.

Everything a live run depends on is fixed here or in the data files this
module writes, before any inference: the one choice question and its 16
criteria, the policy and gate limits (threshold 0.80, max risk 0.05, min
coverage 0.50, alpha 0.05, ``evidence_scope="demo"``), the expected provider
identity (pinned public adapter constants plus the planned interpreter
version), the 959-entry collection schedule (calibration inventory order,
then verification inventory order), the monotonic 90-minute collection
budget and the per-request deadline.

The preregistration document (``data/preregistration.json``) states the
human-readable protocol and the machine fields together: source identity and
file hashes, attribution, selection rule, exact input and inventory hashes,
the sealed lock digest, the schedule digest, the producer (package version,
implementation fingerprint, replay engine) and the SHA-256 of every benchmark
script. Its own ``sha256`` seals every other field. Strict parsing rejects
duplicate keys and nonfinite numbers.

Verification (REVIEW 06) does not trust any declared field: it rebuilds the
COMPLETE expected document from the frozen constants, the committed inputs,
the sealed lock, the recomputed schedule, the current scripts and (when the
hash-verified source is available) the re-derived selection, then compares
the canonical bytes of the committed document with the canonical bytes of
the expected one. Resealing a mutated field therefore never passes. The
committed ``contract.toml`` must be byte-identical to the frozen TOML, and its
SHA-256 is one of the bound fields.

A passing ``--check-preregistration`` proves internal and current-input
consistency only. It is never authority to call the service: Codex's recorded
review of the committed preregistration and a separate live-phase dispatch
are the gate. This module imports no transport: the expected identity is
assembled from pinned constants that a test compares with the adapter's.
"""

from __future__ import annotations

import json
import platform
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Final

import actseal
from actseal.contract import parse_cases, parse_contract, read_input_text
from actseal.errors import ActsealError
from actseal.locking import create_lock, lock_digest, parse_lock, validate_inputs
from actseal.normalization import NORMALIZER_VERSION, request_sha256
from actseal.records import (
    Case,
    CaseRef,
    ChoiceQuestion,
    Contract,
    DecisionRequest,
    GateLimits,
    LockedPolicy,
    ModelIdentity,
    Option,
    PlanLock,
)
from actseal.runner import REQUEST_TIMEOUT_S
from actseal.serialization import (
    canonical_json,
    implementation_fingerprint,
    sha256_bytes,
    strict_json_loads,
    to_data,
)
from jev_audit import source as source_module
from jev_audit.source import Selection, SourceError, jsonl, selection_from_files, verify_source

__all__ = [
    "ATTRIBUTION_FILE",
    "AUDIT_DIR",
    "BUDGET_SECONDS",
    "CALIBRATION_FILE",
    "CONTRACT_FILE",
    "CRITERIA",
    "DATA_DIR",
    "DATA_DIR_REVISION1",
    "DATA_DIR_REVISION2",
    "DATA_FILES",
    "INSTRUCTIONS",
    "LICENSE_COPY_FILE",
    "LOCK_FILE",
    "PREREGISTRATION_FILE",
    "PREREGISTRATION_SCHEMA",
    "PREREGISTRATION_SCHEMA_VERSION",
    "QUESTION_ID",
    "REVIEW_GATE",
    "VERIFICATION_FILE",
    "ScheduleEntry",
    "SelectionSummary",
    "Verified",
    "build_data_files",
    "contract",
    "contract_toml",
    "expected_document",
    "expected_identity",
    "load_preregistration",
    "preregistration_sha256",
    "question",
    "schedule",
    "schedule_sha256",
    "script_hashes",
    "verify_preregistration",
    "write_data_files",
]

AUDIT_DIR: Final = Path(__file__).resolve().parent
#: Historical candidates; their bytes are preserved and they are never active again.
#: Revision 1 is commit e466d9e; revision 2 (commit 47f184f) followed the REVIEW 06 journal
#: repair. Each revision changed only the bound script hashes and the self-seal.
DATA_DIR_REVISION1: Final = AUDIT_DIR / "data"
DATA_DIR_REVISION2: Final = AUDIT_DIR / "data-revision2"
#: The active candidate (V1-038 overflow guards), with identical inputs, contract, lock,
#: license copy and attribution.
DATA_DIR: Final = AUDIT_DIR / "data-revision3"
PREREGISTRATION_FILE: Final = "preregistration.json"
LOCK_FILE: Final = "lock.json"
CONTRACT_FILE: Final = "contract.toml"
CALIBRATION_FILE: Final = "calibration.jsonl"
VERIFICATION_FILE: Final = "verification.jsonl"
LICENSE_COPY_FILE: Final = "BANKING77_LICENSE"
ATTRIBUTION_FILE: Final = "ATTRIBUTION.md"
#: Files the preregistration writer produces (the attribution note is authored).
DATA_FILES: Final[tuple[str, ...]] = (
    CONTRACT_FILE,
    CALIBRATION_FILE,
    VERIFICATION_FILE,
    LOCK_FILE,
    PREREGISTRATION_FILE,
    LICENSE_COPY_FILE,
)
PREREGISTRATION_SCHEMA: Final = "actseal-jev-audit-preregistration"
PREREGISTRATION_SCHEMA_VERSION: Final = 1
#: Monotonic collection budget: no request starts once it is spent (supplement).
BUDGET_SECONDS: Final = 90 * 60
REVIEW_GATE: Final = (
    "A passing --check-preregistration proves internal and current-input consistency "
    "only. Collection requires Codex's recorded review of the committed preregistration "
    "and a separate live-phase dispatch. Any later change to bound source, scripts, "
    "inputs or identity invalidates execution."
)

CONTRACT_NAME: Final = "jev-audit-banking77-16"
QUESTION_ID: Final = "intent"
INSTRUCTIONS: Final = (
    "Classify this online banking customer message into exactly one of the listed "
    "intents. Choose the single intent that best matches what the customer is asking "
    "about or reporting."
)
#: The 16 selected labels (case-sensitive sorted order) and their frozen descriptions.
CRITERIA: Final[tuple[tuple[str, str], ...]] = (
    ("Refund_not_showing_up", "A refund the customer expects has not appeared in their account."),
    ("activate_my_card", "The customer wants to activate a new card."),
    ("age_limit", "Minimum or maximum age to open or use an account."),
    ("apple_pay_or_google_pay", "Using or adding the card with Apple Pay or Google Pay."),
    ("atm_support", "Which ATMs can be used, or how to use the card at an ATM."),
    ("automatic_top_up", "Setting up, changing or understanding automatic top-ups."),
    (
        "balance_not_updated_after_bank_transfer",
        "A bank transfer into the account has not updated the balance.",
    ),
    (
        "balance_not_updated_after_cheque_or_cash_deposit",
        "A cheque or cash deposit has not updated the balance.",
    ),
    ("beneficiary_not_allowed", "A transfer was refused because the beneficiary is not allowed."),
    ("cancel_transfer", "The customer wants to cancel or reverse a transfer they made."),
    (
        "card_about_to_expire",
        "The card is expiring soon and the customer asks about a replacement.",
    ),
    ("card_acceptance", "Where or whether the card is accepted."),
    ("card_arrival", "When an ordered card will arrive, or that it has not arrived."),
    ("card_delivery_estimate", "How long card delivery takes or the estimated delivery time."),
    ("card_linking", "Linking a card to the account or the app."),
    ("card_not_working", "The card does not work when the customer tries to use it."),
)
THRESHOLD: Final = 0.80
MAX_RISK: Final = 0.05
MIN_COVERAGE: Final = 0.50
ALPHA: Final = 0.05
EVIDENCE_SCOPE: Final = "demo"
POPULATION: Final = (
    "Banking77 (PolyAI task-specific-datasets @ 57ec275d, CC-BY-4.0): 16 of 77 intents "
    "selected by case-sensitive label sort; 320 calibration texts from the training split "
    "and 639 deduplicated verification texts from the test split, frozen before inference. "
    "A finite public benchmark subset: demo-scope descriptive evidence only; not the full "
    "77-class task, not IID population evidence, not a powered calibration study, and no "
    "claim about label truth or absence from model training."
)

#: Pinned public constants of ``actseal.experimental.providers.jev`` (tests compare them).
PROVIDER: Final = "jev"
MODEL: Final = "jev-1.13.0"
ADAPTER_VERSION: Final = "1"
ENDPOINT: Final = "https://api.typesafe.ai/v1/systemone"
EXECUTION_PROFILE: Final = "jev-cloud-single-attempt-v1"
TRANSPORT: Final = "stdlib-http.client-tls"
WEIGHTS_ATTESTED: Final = "false"

_SCRIPT_GLOB: Final = "*.py"
_PREREGISTRATION_KEYS: Final[frozenset[str]] = frozenset(
    {
        "schema",
        "schema_version",
        "protocol",
        "source",
        "attribution",
        "selection",
        "contract",
        "expected_identity",
        "inputs",
        "lock_sha256",
        "schedule",
        "collection",
        "metrics",
        "producer",
        "scripts",
        "review_gate",
        "sha256",
    }
)


# --------------------------------------------------------------------------- #
# Frozen question, contract and identity
# --------------------------------------------------------------------------- #


def question() -> ChoiceQuestion:
    return ChoiceQuestion(
        QUESTION_ID, INSTRUCTIONS, tuple(Option(label, text) for label, text in CRITERIA)
    )


def contract() -> Contract:
    labels = tuple(label for label, _ in CRITERIA)
    return Contract(
        1,
        CONTRACT_NAME,
        question(),
        LockedPolicy(labels, labels, THRESHOLD),
        GateLimits(MAX_RISK, MIN_COVERAGE, ALPHA),
        EVIDENCE_SCOPE,
        POPULATION,
    )


def _toml_string(text: str) -> str:
    return json.dumps(text, ensure_ascii=False)


def contract_toml() -> str:
    """The contract as the exact TOML the product parser accepts (``parse_contract``)."""
    lines = [
        "schema_version = 1",
        f"name = {_toml_string(CONTRACT_NAME)}",
        f"evidence_scope = {_toml_string(EVIDENCE_SCOPE)}",
        f"population = {_toml_string(POPULATION)}",
        "",
        "[question]",
        f"question_id = {_toml_string(QUESTION_ID)}",
        f"instructions = {_toml_string(INSTRUCTIONS)}",
        "options = [",
    ]
    lines.extend(
        f"  {{label = {_toml_string(label)}, description = {_toml_string(text)}}},"
        for label, text in CRITERIA
    )
    lines.extend(
        [
            "]",
            "",
            "[policy]",
            "allowed_labels = [",
            *(f"  {_toml_string(label)}," for label, _ in CRITERIA),
            "]",
            f"threshold = {THRESHOLD!r}",
            "",
            "[risk]",
            f"max_risk = {MAX_RISK!r}",
            f"min_coverage = {MIN_COVERAGE!r}",
            f"alpha = {ALPHA!r}",
            "",
        ]
    )
    return "\n".join(lines)


def expected_identity(python_version: str) -> ModelIdentity:
    """The identity the live adapter must report; fixed constants plus the planned interpreter."""
    return ModelIdentity(
        PROVIDER,
        MODEL,
        MODEL,
        (),
        ADAPTER_VERSION,
        NORMALIZER_VERSION,
        (
            ("endpoint", ENDPOINT),
            ("execution_profile", EXECUTION_PROFILE),
            ("python", python_version),
            ("transport", TRANSPORT),
            ("weights_attested", WEIGHTS_ATTESTED),
        ),
    )


# --------------------------------------------------------------------------- #
# Schedule
# --------------------------------------------------------------------------- #


@dataclass(frozen=True, slots=True)
class ScheduleEntry:
    sequence: int
    cohort: str
    case: Case
    request_sha256: str

    @property
    def request(self) -> DecisionRequest:
        return DecisionRequest(self.case.case_id, self.case.state, question())


def schedule(lock: PlanLock, calibration: Sequence[Case]) -> tuple[ScheduleEntry, ...]:
    """All scheduled entries: calibration in inventory order, then verification in lock order."""
    if tuple(case.case_id for case in calibration) != tuple(
        ref.case_id for ref in lock.calibration_inventory
    ):
        raise ActsealError("calibration: cases do not match the locked inventory")
    entries: list[ScheduleEntry] = []
    for cohort, cases in (("calibration", calibration), ("verification", lock.verification_cases)):
        for case in cases:
            request = DecisionRequest(case.case_id, case.state, lock.contract.question)
            entries.append(ScheduleEntry(len(entries) + 1, cohort, case, request_sha256(request)))
    return tuple(entries)


def schedule_sha256(entries: Sequence[ScheduleEntry]) -> str:
    data = [[e.sequence, e.cohort, e.case.case_id, e.request_sha256] for e in entries]
    return sha256_bytes(canonical_json(data))


# --------------------------------------------------------------------------- #
# Preregistration document
# --------------------------------------------------------------------------- #


@dataclass(frozen=True, slots=True)
class SelectionSummary:
    """The source-derived facts the document records about the selection."""

    excluded_training_records: tuple[int, ...]
    duplicate_test_records: tuple[int, ...]

    @classmethod
    def from_selection(cls, selection: Selection) -> SelectionSummary:
        return cls(selection.excluded_training_records, selection.duplicate_test_records)

    @classmethod
    def from_document(cls, document: Mapping[str, object]) -> SelectionSummary:
        """Typed extraction of the two source-only lists when no source is available."""
        selection = _mapping(document, "selection")
        return cls(
            _int_tuple(selection, "excluded_training_records"),
            _int_tuple(selection, "duplicate_test_records"),
        )


def script_hashes(directory: Path = AUDIT_DIR) -> dict[str, str]:
    """SHA-256 of every benchmark script, keyed by file name."""
    return {
        path.name: sha256_bytes(path.read_bytes())
        for path in sorted(directory.glob(_SCRIPT_GLOB))
        if path.is_file()
    }


def preregistration_sha256(document: Mapping[str, object]) -> str:
    data = {key: value for key, value in document.items() if key != "sha256"}
    return sha256_bytes(canonical_json(data))


def _identity_data(identity: ModelIdentity) -> dict[str, object]:
    return {
        "provider": identity.provider,
        "model": identity.model,
        "revision": identity.revision,
        "artifact_hashes": dict(identity.artifact_hashes),
        "adapter_version": identity.adapter_version,
        "normalizer_version": identity.normalizer_version,
        "runtime": dict(identity.runtime),
    }


def _inventory_sha256(inventory: Sequence[CaseRef]) -> str:
    return sha256_bytes(canonical_json([[ref.case_id, ref.sha256] for ref in inventory]))


def expected_document(
    lock: PlanLock,
    *,
    calibration_text: str,
    verification_text: str,
    entries: Sequence[ScheduleEntry],
    summary: SelectionSummary,
    scripts: Mapping[str, str],
    python_version: str,
    contract_toml_bytes: bytes,
) -> dict[str, object]:
    """The complete, sealed document these inputs imply; the only shape a checker accepts."""
    labels = [label for label, _ in CRITERIA]
    document: dict[str, object] = {
        "schema": PREREGISTRATION_SCHEMA,
        "schema_version": PREREGISTRATION_SCHEMA_VERSION,
        "protocol": {
            "title": "Preregistered descriptive Jev audit on a 16-label Banking77 subset",
            "summary": (
                "One frozen protocol, 959 sequential single-attempt requests (320 "
                "calibration, then 639 verification) against the pinned jev-1.13.0 "
                "target. No retry, replacement, tuning, restart or output-based "
                "selection. Calibration is a descriptive cohort, not a threshold-fitting "
                "step. Finite benchmark evidence: not IID population evidence, not the "
                "full 77-class task, no power claim, no model-training-exclusion claim."
            ),
            "gold_handling": (
                "Gold labels and case ids are evaluator metadata. The HTTP body carries "
                "only the exact original text as state, the pinned model and the "
                "locked question; it never carries a case id or gold label."
            ),
        },
        "source": {
            "repository": source_module.SOURCE_REPOSITORY,
            "commit": source_module.SOURCE_COMMIT,
            "tree": source_module.SOURCE_TREE,
            "files": {
                name: {
                    "path": source_module.SOURCE_ORIGINAL_PATHS[name],
                    "size": size,
                    "sha256": digest,
                }
                for name, (size, digest) in source_module.SOURCE_FILES.items()
            },
        },
        "attribution": {
            "license": "CC-BY-4.0",
            "license_copy": LICENSE_COPY_FILE,
            "license_sha256": source_module.SOURCE_FILES["LICENSE"][1],
            "citation": (
                "Casanueva, Temcinas, Gerz, Henderson and Vulic (2020), Efficient Intent "
                "Detection with Dual Sentence Encoders, https://arxiv.org/abs/2003.04807"
            ),
            "notes": "Dataset license is separate from Actseal's Apache-2.0 code license.",
        },
        "selection": {
            "rule": (
                "labels = first 16 of the 77 category strings in case-sensitive sort; "
                "calibration = per label in that order, first 20 training rows in original "
                "record order whose strip().casefold() text is neither a normalized test "
                "text nor already selected; verification = every test row of a selected "
                "label in original test order, first occurrence per normalized text; "
                "original text bytes are the state."
            ),
            "labels": labels,
            "calibration_count": len(lock.calibration_inventory),
            "verification_count": len(lock.verification_inventory),
            "excluded_training_records": list(summary.excluded_training_records),
            "duplicate_test_records": list(summary.duplicate_test_records),
            "case_id_format": "<split>:<1-based data record number>",
        },
        "contract": {
            "name": CONTRACT_NAME,
            "question_id": QUESTION_ID,
            "instructions": INSTRUCTIONS,
            "criteria": [[label, text] for label, text in CRITERIA],
            "allowed_labels": labels,
            "threshold": THRESHOLD,
            "max_risk": MAX_RISK,
            "min_coverage": MIN_COVERAGE,
            "alpha": ALPHA,
            "evidence_scope": EVIDENCE_SCOPE,
            "population": POPULATION,
            "contract_toml_sha256": sha256_bytes(contract_toml_bytes),
        },
        "expected_identity": _identity_data(expected_identity(python_version)),
        "inputs": {
            "calibration_sha256": lock.calibration_sha256,
            "verification_sha256": lock.verification_sha256,
            "calibration_inventory_sha256": _inventory_sha256(lock.calibration_inventory),
            "verification_inventory_sha256": _inventory_sha256(lock.verification_inventory),
            "calibration_rows": calibration_text.count("\n"),
            "verification_rows": verification_text.count("\n"),
        },
        "lock_sha256": lock.sha256,
        "schedule": {
            "entries": len(entries),
            "order": "calibration inventory order, then verification inventory order",
            "sha256": schedule_sha256(entries),
        },
        "collection": {
            "budget_seconds": BUDGET_SECONDS,
            "budget_clock": "time.monotonic, frozen before the first request",
            "request_timeout_s": REQUEST_TIMEOUT_S,
            "attempts_per_case": 1,
            "journal": (
                "durable attempt-start entry before every decide call and a terminal "
                "capture entry immediately after; entries exist only when attempts start "
                "or captures arrive; an interruption partitions the schedule into "
                "captured, started-without-capture and unattempted"
            ),
            "budget_rule": (
                "checked before every request; a request started before the cutoff keeps "
                "its terminal capture even if late; no further request starts; any "
                "budget violation makes the overall audit receipt ERROR while a complete "
                "verification bundle keeps its independently computed verdict"
            ),
        },
        "metrics": {
            "cohorts": "calibration and verification reported separately, never pooled",
            "valid_answers": "every normalized ChoiceAnswer, including ABSTAIN and DENY",
            "coverage": "ACT / scheduled cohort size, complete cohorts only",
            "accepted_error": "wrong ACT / all ACT; null when ACT = 0 or cohort incomplete",
            "reliability_bins": (
                "10 equal-width bins on the selected-option probability p: bin i holds "
                "i/10 <= p < (i+1)/10 for i in 0..8 and 0.9 <= p <= 1 for i = 9, using "
                "Python float comparison against the edges i/10"
            ),
            "ece": "sum over nonempty bins of n_bin/n_valid * |mean p - accuracy|",
            "brier": (
                "mean over valid answers of sum over all 16 options of "
                "(normalized probability - one-hot gold)^2; range [0, 2]"
            ),
            "null_rules": "empty bins, n_valid = 0 metrics and unmeasured spend are null",
        },
        "producer": {
            "package": "actseal",
            "package_version": actseal.__version__,
            "implementation_sha256": lock.implementation_sha256,
            "replay_engine_version": lock.replay_engine_version,
            "python_version": python_version,
        },
        "scripts": dict(sorted(scripts.items())),
        "review_gate": REVIEW_GATE,
    }
    document["sha256"] = preregistration_sha256(document)
    return document


def build_data_files(
    selection: Selection,
    source_files: Mapping[str, bytes],
    *,
    scripts: Mapping[str, str] | None = None,
    python_version: str | None = None,
) -> dict[str, bytes]:
    """Every preregistration data file as bytes: inputs, contract, lock, document, license."""
    version = python_version or platform.python_version()
    calibration_text = jsonl(selection.calibration)
    verification_text = jsonl(selection.verification)
    lock = create_lock(contract(), calibration_text, verification_text, expected_identity(version))
    calibration_cases = parse_cases(calibration_text, lock.contract.question)
    entries = schedule(lock, calibration_cases)
    toml_bytes = contract_toml().encode("utf-8")
    document = expected_document(
        lock,
        calibration_text=calibration_text,
        verification_text=verification_text,
        entries=entries,
        summary=SelectionSummary.from_selection(selection),
        scripts=script_hashes() if scripts is None else scripts,
        python_version=version,
        contract_toml_bytes=toml_bytes,
    )
    return {
        CONTRACT_FILE: toml_bytes,
        CALIBRATION_FILE: calibration_text.encode("utf-8"),
        VERIFICATION_FILE: verification_text.encode("utf-8"),
        LOCK_FILE: canonical_json(to_data(lock)) + b"\n",
        PREREGISTRATION_FILE: canonical_json(document) + b"\n",
        LICENSE_COPY_FILE: source_files["LICENSE"],
    }


def write_data_files(directory: Path, files: Mapping[str, bytes]) -> None:
    """Write new files only; an existing preregistration is never rewritten in place."""
    directory.mkdir(parents=True, exist_ok=True)
    for name in files:
        if (directory / name).exists():
            raise FileExistsError(f"{name}: already exists; a preregistration is never rewritten")
    for name, data in files.items():
        with (directory / name).open("xb") as stream:
            stream.write(data)


# --------------------------------------------------------------------------- #
# Loading and verification
# --------------------------------------------------------------------------- #


def _mapping(document: Mapping[str, object], key: str) -> Mapping[str, object]:
    value = document.get(key)
    if type(value) is not dict:
        raise ActsealError(f"preregistration.{key}: expected object")
    return value


def _int_tuple(mapping: Mapping[str, object], key: str) -> tuple[int, ...]:
    value = mapping.get(key)
    if type(value) is not list or any(type(item) is not int for item in value):
        raise ActsealError(f"preregistration.selection.{key}: expected a list of integers")
    return tuple(value)


def load_preregistration(path: Path) -> dict[str, object]:
    """Strictly decode the document, check its key set and self-seal; never repair it."""
    value = strict_json_loads(read_input_text(path))
    if type(value) is not dict or set(value) != _PREREGISTRATION_KEYS:
        raise ActsealError("preregistration: unexpected document shape")
    if value["schema"] != PREREGISTRATION_SCHEMA or value["schema_version"] != 1:
        raise ActsealError("preregistration: unsupported schema")
    if value["sha256"] != preregistration_sha256(value):
        raise ActsealError("preregistration: self-seal does not match the document")
    return value


@dataclass(frozen=True, slots=True)
class Verified:
    """Everything a run or checker needs, plus the findings that would forbid a run."""

    preregistration: dict[str, object]
    lock: PlanLock
    calibration_text: str
    verification_text: str
    calibration_cases: tuple[Case, ...]
    entries: tuple[ScheduleEntry, ...]
    findings: tuple[str, ...]
    source_verified: bool

    @property
    def preregistration_sha256(self) -> str:
        value = self.preregistration["sha256"]
        if not isinstance(value, str):  # pragma: no cover - load_preregistration sealed it
            raise ActsealError("preregistration.sha256: expected string")
        return value


def _differing_groups(document: Mapping[str, object], expected: Mapping[str, object]) -> list[str]:
    """Top-level keys whose canonical bytes differ (for the report; equality is byte-exact)."""
    return sorted(
        key
        for key in set(document) | set(expected)
        if key not in document
        or key not in expected
        or canonical_json(document[key]) != canonical_json(expected[key])
    )


def verify_preregistration(
    data_dir: Path,
    *,
    source_dir: Path | None,
    scripts: Mapping[str, str] | None = None,
    python_version: str | None = None,
) -> Verified:
    """Check the committed data for internal and current-input consistency without any key.

    Findings are accumulated, not raised, so a report can list them all; a run
    requires zero findings AND a verified source. ``source_dir=None`` skips
    source re-derivation, takes the two source-only lists from the committed
    document under strict typing, and records ``source_verified=False``.
    """
    findings: list[str] = []
    version = python_version or platform.python_version()
    document = load_preregistration(data_dir / PREREGISTRATION_FILE)
    lock = parse_lock(read_input_text(data_dir / LOCK_FILE))
    calibration_text = read_input_text(data_dir / CALIBRATION_FILE)
    verification_text = read_input_text(data_dir / VERIFICATION_FILE)
    toml_bytes = (data_dir / CONTRACT_FILE).read_bytes()
    if lock_digest(lock) != lock.sha256:
        findings.append("lock: self-seal does not match the lock contents")
    try:
        validate_inputs(lock, calibration_text, verification_text)
    except ActsealError as exc:
        findings.append(f"inputs: {exc}")
    if lock.contract != contract():
        findings.append("contract: locked contract differs from the frozen protocol")
    if toml_bytes != contract_toml().encode("utf-8"):
        findings.append("contract.toml: bytes differ from the frozen protocol TOML")
    try:
        if parse_contract(data_dir / CONTRACT_FILE) != contract():
            findings.append("contract.toml: parses to a different contract")
    except ActsealError as exc:
        findings.append(f"contract.toml: {exc}")
    if lock.model_identity != expected_identity(version):
        findings.append("identity: locked identity differs from the expected identity")
    if lock.implementation_sha256 != implementation_fingerprint():
        findings.append("producer: lock fingerprint is not the running implementation")
    license_copy = (data_dir / LICENSE_COPY_FILE).read_bytes()
    if sha256_bytes(license_copy) != source_module.SOURCE_FILES["LICENSE"][1]:
        findings.append("attribution: license copy differs from the pinned LICENSE")
    calibration_cases = parse_cases(calibration_text, lock.contract.question)
    entries: tuple[ScheduleEntry, ...] = ()
    try:
        entries = schedule(lock, calibration_cases)
    except ActsealError as exc:
        findings.append(f"schedule: {exc}")
    source_verified = False
    summary: SelectionSummary | None = None
    if source_dir is not None:
        try:
            selection = selection_from_files(verify_source(source_dir))
        except SourceError as exc:
            findings.append(f"source: {exc}")
        else:
            if jsonl(selection.calibration) != calibration_text:
                findings.append("source: re-derived calibration differs from the committed input")
            if jsonl(selection.verification) != verification_text:
                findings.append("source: re-derived verification differs from the committed input")
            summary = SelectionSummary.from_selection(selection)
            source_verified = not any(f.startswith("source") for f in findings)
    if summary is None:
        try:
            summary = SelectionSummary.from_document(document)
        except ActsealError as exc:
            findings.append(str(exc))
            summary = SelectionSummary((), ())
    expected = expected_document(
        lock,
        calibration_text=calibration_text,
        verification_text=verification_text,
        entries=entries,
        summary=summary,
        scripts=script_hashes() if scripts is None else scripts,
        python_version=version,
        contract_toml_bytes=toml_bytes,
    )
    if canonical_json(document) != canonical_json(expected):
        groups = ", ".join(_differing_groups(document, expected))
        findings.append(f"preregistration: differs from the reconstructed document in: {groups}")
    return Verified(
        document,
        lock,
        calibration_text,
        verification_text,
        calibration_cases,
        entries,
        tuple(findings),
        source_verified,
    )
