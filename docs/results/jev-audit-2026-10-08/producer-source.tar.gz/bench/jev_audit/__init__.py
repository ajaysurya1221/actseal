"""Preregistered Jev audit benchmark (plan/v1 Task 06; benchmark-owned, not product code).

Nothing here is part of the ``actseal`` package or its stability promise. The
modules reuse the frozen product authorities (records, contract parsing,
locking, normalization, policy, faults, assessment, evidence and replay) and
add only what the audit protocol needs: pinned source verification and
selection (``source``), the frozen protocol and preregistration document
(``protocol``), prespecified descriptive metrics (``metrics``), the durable
attempt journal (``journal``), the sequential collector (``collect``), the
offline receipt reconstruction and checker (``receipts``) and the command line
(``run``). Importing any module performs no network, key or environment
access; the live adapter is imported only inside the ``--execute`` path.
"""
