"""Pinned Banking77 source bytes and the frozen selection rule (PLAN section C).

Source: PolyAI ``task-specific-datasets`` at commit ``57ec275d`` (CC-BY-4.0;
see ``data/ATTRIBUTION.md``). Every file is verified by size and SHA-256
against the receipt in plan/v1/tasks/06.md before any byte is used.

Selection (frozen before inference, reproduced independently by Codex):

* labels: the first 16 of the 77 category strings in Python's case-sensitive
  sort;
* calibration: for each selected label, in that label order, the first 20
  training rows (original record order) whose normalized text is neither a
  normalized test text nor already selected; original text bytes are kept;
* verification: every test row of a selected label, in original test order,
  keeping only the first occurrence of each normalized text;
* normalization is exactly ``text.strip().casefold()`` and is used only for
  exclusion and deduplication, never to rewrite the state sent to a provider.

Case ids bind the split and the original 1-based data record number
(``train:3104``, ``test:1462``), never a model outcome.
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Final

__all__ = [
    "CALIBRATION_PER_LABEL",
    "DEFAULT_SOURCE_DIR",
    "EXPECTED_CALIBRATION",
    "EXPECTED_VERIFICATION",
    "SELECTED_LABEL_COUNT",
    "SOURCE_COMMIT",
    "SOURCE_FILES",
    "SOURCE_ORIGINAL_PATHS",
    "SOURCE_REPOSITORY",
    "SOURCE_TREE",
    "Selection",
    "SourceError",
    "SourceRow",
    "jsonl",
    "normalize_text",
    "read_rows",
    "select",
    "selection_from_files",
    "verify_selection",
    "verify_source",
]

SOURCE_REPOSITORY: Final = "https://github.com/PolyAI-LDN/task-specific-datasets"
SOURCE_COMMIT: Final = "57ec275d8078af65b7731c2a98be812d844a6d6b"
SOURCE_TREE: Final = "05eb3f1c7b43a6e1f2b8576b882115423e9031e3"
#: Cached file name -> (size in bytes, SHA-256), from the Task 06 source receipt.
SOURCE_FILES: Final[Mapping[str, tuple[int, str]]] = {
    "LICENSE": (18650, "7e7170e3cebf88a9f60c7b8421418323c09304da1af4d5e90f4da1dc1c8a2661"),
    "README.md": (4735, "7b9ce9069931cc2de89dce8c7ffb53d07806cf413601ccf133b9af5227b3a373"),
    "categories.json": (
        2036,
        "53261da888122daf2d120d925458631d9619e15d82e56052e7a42e535ce32b63",
    ),
    "test.csv": (239961, "d12d6e3bc4c3103966ae786dc435913c0c563dfa328f5a3646d0e62cfeeb474d"),
    "train.csv": (839073, "b06e26ac675513959a63135f11b94ea7786ed02da65db93a5650d8838cbc664b"),
}
#: Cached file name -> path inside the pinned repository tree.
SOURCE_ORIGINAL_PATHS: Final[Mapping[str, str]] = {
    "LICENSE": "LICENSE",
    "README.md": "README.md",
    "categories.json": "banking_data/categories.json",
    "test.csv": "banking_data/test.csv",
    "train.csv": "banking_data/train.csv",
}
DEFAULT_SOURCE_DIR: Final = Path("/tmp/actseal-v1-orchestration/banking77-source-57ec275d")  # noqa: S108 - the hash-verified cache location recorded in the Task 06 receipt
SELECTED_LABEL_COUNT: Final = 16
CALIBRATION_PER_LABEL: Final = 20
EXPECTED_CALIBRATION: Final = 320
EXPECTED_VERIFICATION: Final = 639
_HEADER: Final = ["text", "category"]


class SourceError(Exception):
    """The cached source or the selection does not match the pinned receipt."""


@dataclass(frozen=True, slots=True)
class SourceRow:
    """One original row: split, 1-based data record number, exact text, label."""

    split: str
    record: int
    text: str
    label: str

    @property
    def case_id(self) -> str:
        return f"{self.split}:{self.record}"


@dataclass(frozen=True, slots=True)
class Selection:
    labels: tuple[str, ...]
    calibration: tuple[SourceRow, ...]
    verification: tuple[SourceRow, ...]
    excluded_training_records: tuple[int, ...]
    duplicate_test_records: tuple[int, ...]


def normalize_text(text: str) -> str:
    """The frozen exclusion/deduplication key; never applied to a sent state."""
    return text.strip().casefold()


def verify_source(directory: Path) -> dict[str, bytes]:
    """Read the five cached files and check each size and SHA-256; return their bytes."""
    files: dict[str, bytes] = {}
    for name, (size, digest) in SOURCE_FILES.items():
        path = directory / name
        try:
            with path.open("rb") as stream:
                data = stream.read(size + 1)
        except OSError as exc:
            raise SourceError(f"{name}: cannot read the cached source file") from exc
        if len(data) != size:
            raise SourceError(f"{name}: size does not match the pinned receipt")
        if hashlib.sha256(data).hexdigest() != digest:
            raise SourceError(f"{name}: SHA-256 does not match the pinned receipt")
        files[name] = data
    return files


def read_rows(split: str, data: bytes) -> tuple[SourceRow, ...]:
    """Parse one original CSV split into rows with 1-based data record numbers."""
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise SourceError(f"{split}: not valid UTF-8") from exc
    reader = csv.reader(io.StringIO(text, newline=""))
    header = next(reader, None)
    if header != _HEADER:
        raise SourceError(f"{split}: unexpected CSV header")
    rows: list[SourceRow] = []
    for record, fields in enumerate(reader, start=1):
        if len(fields) != len(_HEADER) or not fields[0] or not fields[1]:
            raise SourceError(f"{split}: record {record} is malformed")
        rows.append(SourceRow(split, record, fields[0], fields[1]))
    return tuple(rows)


def select(
    train: Sequence[SourceRow],
    test: Sequence[SourceRow],
    categories: Sequence[str],
    *,
    label_count: int = SELECTED_LABEL_COUNT,
    per_label: int = CALIBRATION_PER_LABEL,
) -> Selection:
    """Apply the frozen selection rule; raises on a label-conflicting normalized text."""
    if len(set(categories)) != len(categories):
        raise SourceError("categories: duplicate label")
    seen_labels = {row.label for row in train} | {row.label for row in test}
    if seen_labels != set(categories):
        raise SourceError("categories: do not match the labels present in the splits")
    by_text: dict[str, set[str]] = {}
    for row in (*train, *test):
        by_text.setdefault(normalize_text(row.text), set()).add(row.label)
    if any(len(labels) > 1 for labels in by_text.values()):
        raise SourceError("source: a normalized text carries conflicting labels")
    labels = tuple(sorted(categories)[:label_count])
    test_texts = {normalize_text(row.text) for row in test}
    calibration: list[SourceRow] = []
    excluded: list[int] = []
    chosen: set[str] = set()
    for label in labels:
        taken = 0
        for row in train:
            if row.label != label:
                continue
            key = normalize_text(row.text)
            if key in test_texts:
                # Recorded for every selected-label training row, cap reached or not,
                # so the list matches the independent source receipt.
                excluded.append(row.record)
                continue
            if taken >= per_label or key in chosen:
                continue
            chosen.add(key)
            calibration.append(row)
            taken += 1
    verification: list[SourceRow] = []
    duplicates: list[int] = []
    selected = set(labels)
    kept: set[str] = set()
    for row in test:
        if row.label not in selected:
            continue
        key = normalize_text(row.text)
        if key in kept:
            duplicates.append(row.record)
            continue
        kept.add(key)
        verification.append(row)
    return Selection(
        labels, tuple(calibration), tuple(verification), tuple(excluded), tuple(duplicates)
    )


def verify_selection(selection: Selection) -> None:
    """The frozen expectations: 16 labels, 320 (20 per label) calibration, 639 verification."""
    if len(selection.labels) != SELECTED_LABEL_COUNT:
        raise SourceError("selection: label count differs from the frozen protocol")
    if len(selection.calibration) != EXPECTED_CALIBRATION:
        raise SourceError("selection: calibration count differs from the frozen protocol")
    if len(selection.verification) != EXPECTED_VERIFICATION:
        raise SourceError("selection: verification count differs from the frozen protocol")
    for label in selection.labels:
        if sum(row.label == label for row in selection.calibration) != CALIBRATION_PER_LABEL:
            raise SourceError("selection: a label has the wrong calibration count")
    calibration_keys = {normalize_text(row.text) for row in selection.calibration}
    verification_keys = {normalize_text(row.text) for row in selection.verification}
    if len(calibration_keys) != len(selection.calibration):
        raise SourceError("selection: calibration texts are not unique after normalization")
    if len(verification_keys) != len(selection.verification):
        raise SourceError("selection: verification texts are not unique after normalization")
    if calibration_keys & verification_keys:
        raise SourceError("selection: calibration and verification overlap after normalization")


def selection_from_files(files: Mapping[str, bytes]) -> Selection:
    """Parse the verified source bytes and apply the frozen rule and expectations."""
    try:
        categories = json.loads(files["categories.json"].decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise SourceError("categories.json: invalid JSON") from exc
    if not isinstance(categories, list) or any(type(item) is not str for item in categories):
        raise SourceError("categories.json: expected a list of strings")
    selection = select(
        read_rows("train", files["train.csv"]), read_rows("test", files["test.csv"]), categories
    )
    verify_selection(selection)
    return selection


def jsonl(rows: Sequence[SourceRow]) -> str:
    """The exact JSONL split text locked by the preregistration (one LF per row)."""
    return "".join(
        json.dumps(
            {"case_id": row.case_id, "state": row.text, "expected_label": row.label},
            ensure_ascii=False,
            allow_nan=False,
        )
        + "\n"
        for row in rows
    )
