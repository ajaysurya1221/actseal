"""The sequential single-attempt collector behind ``run.py --execute``.

Order of work, fixed by the supplement:

1. Refuse an existing output directory: a started run is never restarted.
2. Verify the preregistration against the current scripts, the committed
   inputs, the running implementation and the hash-verified source; any
   finding stops the run before a key is read or a provider exists.
3. Create the run directory, copy the preregistration inputs into it and
   write ``run.json``.
4. Build ONE provider through the factory (the only place a real key may be
   read), compare its observed identity with the locked identity, and stop
   without a request on any difference.
5. Freeze the monotonic budget, journal ``budget_start``, then for every
   scheduled entry in order: check the budget (stop before starting a request
   once it is spent), journal ``attempt_start``, call ``decide`` once with the
   fixed per-request deadline, journal the terminal capture (late or not).
6. Journal ``run_end``, close the provider, finalize from the journal.

Nothing here retries, replaces or reorders a case, fabricates a capture or
inspects an answer. The live adapter module is imported only inside
``default_model_factory``; tests inject provider, clock and factory doubles.
"""

from __future__ import annotations

import os
import platform
import secrets
import time
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING

from actseal.errors import ActsealError, IntegrityError
from actseal.runner import REQUEST_TIMEOUT_S
from actseal.serialization import canonical_json
from jev_audit.journal import (
    JOURNAL_FILE,
    UTC_FORMAT,
    FileJournal,
    Journal,
    attempt_entry,
    budget_entry,
    capture_entry,
    deadline_utc,
    end_entry,
)
from jev_audit.protocol import (
    BUDGET_SECONDS,
    DATA_DIR,
    DATA_FILES,
    Verified,
    verify_preregistration,
)
from jev_audit.receipts import INPUTS_DIR, RUN_FILE, RUN_SCHEMA, SCHEMA_VERSION, finalize

if TYPE_CHECKING:
    from actseal.adapters.base import DecisionModel

__all__ = ["Clock", "ModelFactory", "default_model_factory", "execute", "prepare_run", "utc_now"]

ModelFactory = Callable[[], "DecisionModel"]
Clock = Callable[[], float]


def utc_now() -> str:
    return datetime.now(UTC).strftime(UTC_FORMAT)


def default_model_factory() -> DecisionModel:
    """The live adapter; constructing it reads ``JEV_API_KEY`` and nothing else."""
    from actseal.experimental.providers.jev import JevModel  # noqa: PLC0415 - live path only

    return JevModel()


def prepare_run(
    out: Path,
    *,
    data_dir: Path = DATA_DIR,
    source_dir: Path | None,
    python_version: str | None = None,
    require_source: bool = True,
) -> tuple[Verified, str]:
    """Steps 1-3: refuse a started directory, verify everything, create the run directory.

    ``require_source`` is ``True`` on every command-line path: a live run needs
    the hash-verified source. Only tests with synthetic inputs pass ``False``.
    """
    if "\x00" in os.fspath(out):
        raise ActsealError("out: must not contain NUL")
    if os.path.lexists(out):
        raise FileExistsError("out: already exists; a started run is never restarted")
    verified = verify_preregistration(
        data_dir, source_dir=source_dir, python_version=python_version
    )
    if verified.findings:
        raise ActsealError("preregistration: " + "; ".join(verified.findings))
    if require_source and not verified.source_verified:
        raise ActsealError("source: the hash-verified source is required before any request")
    out.mkdir(parents=False, exist_ok=False)
    inputs = out / INPUTS_DIR
    inputs.mkdir()
    for name in DATA_FILES:
        with (inputs / name).open("xb") as stream:
            stream.write((data_dir / name).read_bytes())
    run_id = secrets.token_hex(16)
    document: dict[str, object] = {
        "schema": RUN_SCHEMA,
        "schema_version": SCHEMA_VERSION,
        "run_id": run_id,
        "preregistration_sha256": verified.preregistration_sha256,
        "lock_sha256": verified.lock.sha256,
        "scheduled": len(verified.entries),
        "python_version": python_version or platform.python_version(),
        "created_utc": utc_now(),
    }
    with (out / RUN_FILE).open("xb") as stream:
        stream.write(canonical_json(document) + b"\n")
    return verified, run_id


def _collect(
    verified: Verified,
    run_id: str,
    model: DecisionModel,
    journal: Journal,
    *,
    clock: Clock,
    now: Callable[[], str],
) -> None:
    """Step 5-6: the sequential loop; every durable write precedes the action it records.

    The budget is the preregistered ``BUDGET_SECONDS`` (the verifier has already
    checked that the bound document says the same); it cannot be overridden.
    """
    digest = verified.preregistration_sha256
    budget_seconds = BUDGET_SECONDS
    start = clock()
    start_utc = now()
    journal.append(
        budget_entry(
            run_id,
            digest,
            budget_seconds=budget_seconds,
            start_utc=start_utc,
            deadline_utc=deadline_utc(start_utc, budget_seconds),
        )
    )
    budget_exceeded = False
    stopped = "complete"
    for entry in verified.entries:
        elapsed = clock() - start
        if elapsed >= budget_seconds:
            budget_exceeded = True
            stopped = "budget_exceeded"
            break
        journal.append(attempt_entry(run_id, digest, entry, started_utc=now(), monotonic_s=elapsed))
        capture = model.decide(entry.request, timeout_s=REQUEST_TIMEOUT_S)
        finished = clock() - start
        late = finished > budget_seconds
        budget_exceeded = budget_exceeded or late
        journal.append(
            capture_entry(run_id, digest, entry, capture, monotonic_s=finished, late=late)
        )
    journal.append(
        end_entry(
            run_id,
            digest,
            monotonic_s=clock() - start,
            stopped=stopped,
            budget_exceeded=budget_exceeded,
        )
    )


def execute(
    out: Path,
    *,
    data_dir: Path = DATA_DIR,
    source_dir: Path | None,
    model_factory: ModelFactory = default_model_factory,
    clock: Clock = time.monotonic,
    now: Callable[[], str] = utc_now,
    python_version: str | None = None,
    require_source: bool = True,
) -> Path:
    """Run the whole protocol once into the NEW directory ``out``; return the receipt path.

    A ``BaseException`` from the provider (for example ``KeyboardInterrupt``)
    propagates after the journal and provider are closed; the partial journal
    is preserved and ``finalize`` can later produce the incomplete receipt.
    """
    verified, run_id = prepare_run(
        out,
        data_dir=data_dir,
        source_dir=source_dir,
        python_version=python_version,
        require_source=require_source,
    )
    journal = FileJournal(out / JOURNAL_FILE)
    try:
        model = model_factory()
        try:
            if model.identity() != verified.lock.model_identity:
                raise IntegrityError(
                    "model_identity: observed identity does not match the preregistered lock"
                )
            _collect(verified, run_id, model, journal, clock=clock, now=now)
        finally:
            model.close()
    finally:
        journal.close()
    return finalize(out)
